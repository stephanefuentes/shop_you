<?php


class Steph
{

    public function test()
    {
       echo "bravo Stéph";
    }

}





