<?php include('../header.php'); ?>


<h1>Detail d'une commande ( via l'admin )</h1>
<?php include('../footer.php'); ?>