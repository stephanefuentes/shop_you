<?php include('../header.php'); ?>


<h1>Liste des commandes ( coté admin )</h1>
<?php include('../footer.php'); ?>