<?php include('../header.php'); ?>


<h1>Edition d'un admin
</h1>




<?php include('../footer.php'); ?>