<?php include('header.php'); ?>


<h1>Bienvenu sur ce beau site</h1>




<?php include('footer.php'); ?>