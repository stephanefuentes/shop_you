<?php include('../header.php'); ?>


<h1>Profile</h1>
<?php include('../footer.php'); ?>