<?php include('views/header.php'); ?>


<h1>Dashboard Utilisateur</h1>


<?php include('views/footer.php'); ?>