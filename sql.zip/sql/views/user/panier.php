<?php include('header.php'); ?>


<h1>Votre panier</h1>
<?php include('footer.php'); ?>