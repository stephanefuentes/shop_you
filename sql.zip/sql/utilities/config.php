<?php


define('DB_NAME', "boutique");
define('DB_HOST', "localhost");
define('DB_USER', "root");
define('DB_PASS', "troiswa");
